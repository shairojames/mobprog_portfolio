var typed = new Typed(".educ-text", {
    strings: ["Educational Background"],
    typeSpeed: 100,
    backspeed: 100,
    backDelay: 1000,
    loop: true
})

var typed = new Typed(".people-text", {
    strings: ["People Arround Me"],
    typeSpeed: 100,
    backspeed: 100,
    backDelay: 1000,
    loop: true
})


var typed = new Typed(".info-text", {
    strings: ["Contact Info"],
    typeSpeed: 100,
    backspeed: 100,
    backDelay: 1000,
    loop: true
})
